"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Symbol {
    constructor(name, type, kind, index) {
        this.name = name;
        this.type = type;
        this.kind = kind;
        this.index = index;
    }
}
exports.Symbol = Symbol;
