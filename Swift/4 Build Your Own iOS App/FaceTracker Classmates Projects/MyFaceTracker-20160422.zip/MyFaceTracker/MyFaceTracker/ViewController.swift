//
//  ViewController.swift
//  MyFaceTracker
//
//  Created by Philippe Wanner on 13.04.16.
//  Copyright © 2016 Philippe Wanner. All rights reserved.
//

import UIKit
import FaceTracker

class ViewController: UIViewController, FaceTrackerViewControllerDelegate {
    
    var hatView = UIImageView()
    var leftEyeView = UIImageView()
    var rightEyeView = UIImageView()
    var pointViews = [UIView]()
    weak var faceTrackerViewController: FaceTrackerViewController?
    
    @IBOutlet var activityIndicator: UIActivityIndicatorView!
    @IBOutlet var optionsButton: UIButton!
    @IBOutlet var faceTrackerContainerView: UIView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.view.insertSubview(hatView, aboveSubview: faceTrackerContainerView)
        self.view.insertSubview(leftEyeView, aboveSubview: faceTrackerContainerView)
        self.view.insertSubview(rightEyeView, aboveSubview: faceTrackerContainerView)
        hatView.image = UIImage(named: "hat")
        leftEyeView.image = UIImage(named: "eye")
        rightEyeView.image = UIImage(named: "eye")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if(segue.identifier == "faceTrackerEmbed"){
            faceTrackerViewController = segue.destinationViewController as? FaceTrackerViewController
            faceTrackerViewController!.delegate = self
        }
    }
    
    override func  viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        faceTrackerViewController!.startTracking{ () -> Void in
        
        }
    }
    
    //Actual protocol implementation
    func faceTrackerDidUpdate(points: FacePoints?) {
        if let points = points {
            // Allocate some views for the points if needed
            if (pointViews.count == 0) {
                let numPoints = points.getTotalNumberOFPoints()
                for _ in 0...numPoints {
                    let view = UIView()
                    view.backgroundColor = UIColor.greenColor()
                    self.view.addSubview(view)
                    
                    pointViews.append(view)
                }
            }
            
            // Set frame for each point view
            /*
            points.enumeratePoints({ (point, index) -> Void in
                let pointView = self.pointViews[index]
                let pointSize: CGFloat = 4
                
                pointView.hidden = false
                pointView.frame = CGRectIntegral(CGRectMake(point.x - pointSize / 2, point.y - pointSize / 2, pointSize, pointSize))
            })*/
            
            self.computeHatFrame(points)
            self.computeLeftEyeFrame(points)
            self.computeRightEyeFrame(points)
            
        }
        else {
            hatView.hidden = true
            leftEyeView.hidden = true
            
            for view in pointViews {
                view.hidden = true
            }
        }

    }
    
    private func computeRightEyeFrame(points: FacePoints){
        // Compute the left eye frame
        let rightEyeCenter = CGPointMake((points.rightEye[0].x + points.rightEye[5].x)/2, (points.rightEye[0].y + points.rightEye[5].y)/2)
        
        let rightEyeWidth = sqrt(pow(points.rightEye[0].x - points.rightEye[5].x, 2) + pow(points.rightEye[0].y - points.rightEye[5].y, 2))
        let rightEyeHeight = (rightEyeView.image!.size.height / rightEyeView.image!.size.width) * rightEyeWidth
        
        rightEyeView.transform = CGAffineTransformIdentity
        
        rightEyeView.frame = CGRectMake(rightEyeCenter.x - rightEyeWidth / 2, rightEyeCenter.y - rightEyeHeight / 2, rightEyeWidth, rightEyeHeight)
        rightEyeView.hidden = false
        
        setAnchorPoint(CGPointMake(0.5, 1.0), forView: rightEyeView)
        
        let angle = atan2(points.rightEye[5].y - points.rightEye[0].y, points.rightEye[5].x - points.leftEye[0].x)
        rightEyeView.transform = CGAffineTransformMakeRotation(angle)
    }
    
    private func computeLeftEyeFrame(points: FacePoints){
        // Compute the left eye frame
        let leftEyeCenter = CGPointMake((points.leftEye[0].x + points.leftEye[5].x)/2, (points.leftEye[0].y + points.leftEye[5].y)/2)
        
        let leftEyeWidth = sqrt(pow(points.leftEye[0].x - points.leftEye[5].x, 2) + pow(points.leftEye[0].y - points.leftEye[5].y, 2))
        let leftEyeHeight = (leftEyeView.image!.size.height / leftEyeView.image!.size.width) * leftEyeWidth
        
        leftEyeView.transform = CGAffineTransformIdentity
        
        leftEyeView.frame = CGRectMake(leftEyeCenter.x - leftEyeWidth / 2, leftEyeCenter.y - leftEyeHeight/2, leftEyeWidth, leftEyeHeight)
        leftEyeView.hidden = false
        
        setAnchorPoint(CGPointMake(0.5, 1.0), forView: leftEyeView)
        
        let angle = atan2(points.rightEye[5].y - points.leftEye[0].y, points.rightEye[5].x - points.leftEye[0].x)
        leftEyeView.transform = CGAffineTransformMakeRotation(angle)
    }
    
    
    

    private func computeHatFrame(points: FacePoints){
        // Compute the hat frame
        let eyeCornerDist = sqrt(pow(points.leftEye[0].x - points.rightEye[5].x, 2) + pow(points.leftEye[0].y - points.rightEye[5].y, 2))
        let eyeToEyeCenter = CGPointMake((points.leftEye[0].x + points.rightEye[5].x) / 2, (points.leftEye[0].y + points.rightEye[5].y) / 2)
        
        let hatWidth = 2.0 * eyeCornerDist
        let hatHeight = (hatView.image!.size.height / hatView.image!.size.width) * hatWidth
        
        hatView.transform = CGAffineTransformIdentity
        
        hatView.frame = CGRectMake(eyeToEyeCenter.x - hatWidth / 2, eyeToEyeCenter.y - 1.3 * hatHeight, hatWidth, hatHeight)
        hatView.hidden = false
        
        setAnchorPoint(CGPointMake(0.5, 1.0), forView: hatView)
        
        let angle = atan2(points.rightEye[5].y - points.leftEye[0].y, points.rightEye[5].x - points.leftEye[0].x)
        hatView.transform = CGAffineTransformMakeRotation(angle)
    }
    
    private func setAnchorPoint(anchorPoint: CGPoint, forView view: UIView) {
        var newPoint = CGPointMake(view.bounds.size.width * anchorPoint.x, view.bounds.size.height * anchorPoint.y)
        var oldPoint = CGPointMake(view.bounds.size.width * view.layer.anchorPoint.x, view.bounds.size.height * view.layer.anchorPoint.y)
        
        newPoint = CGPointApplyAffineTransform(newPoint, view.transform)
        oldPoint = CGPointApplyAffineTransform(oldPoint, view.transform)
        
        var position = view.layer.position
        position.x -= oldPoint.x
        position.x += newPoint.x
        
        position.y -= oldPoint.y
        position.y += newPoint.y
        
        view.layer.position = position
        view.layer.anchorPoint = anchorPoint
    }
}

