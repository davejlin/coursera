#include <stdio.h>
#include <stdlib.h>

int main(void) {
  printf("Hello World\n");
  return EXIT_SUCCESS;
}
