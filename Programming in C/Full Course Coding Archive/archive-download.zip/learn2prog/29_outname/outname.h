#ifndef __OUTNAME_H__
#define __OUTNAME_H__

char * computeOutputFileName(const char * inputName);

#endif
